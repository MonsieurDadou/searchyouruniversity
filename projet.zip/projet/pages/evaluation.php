<?php
	session_start()
 ?>

<!DOCTYPE html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="../layout/styles/layout.css" type="text/css" />
<link rel="stylesheet" href="../layout/styles/catalogue.css" type="text/css" />
<title>Faire une évaluation </title>
<script type="text/javascript" src="../layout/scripts/jquery.js"></script>
<script type="text/javascript" src="../layout/scripts/jquery.chained.js"></script>
<script type="text/javascript">
$(function(){
    $("#departement").chained("#region");
});
$(function(){
    $("#discipline").chained("#intitule_gd");
});
$(function(){
    $("#etablissement").chained("#departement");
});
</script>
</head>
<body>

<div class="wrapper row1">
  <div id="topnav">
    <ul>
      <li><a href="../index.php"><strong>Accueil</strong></a></li>
      <li><a href="catalogue.php"><strong>Catalogue des universités</strong></a></li>
      <li class="active"><a href="evaluation.php"><strong>Faire une évaluation</strong></a></li>
	  <?php
	  if(isset($_SESSION['utilisateur'])){
		echo '<li><a href="utilisateur/vosuniversites.php"><strong>Recherche guidée</strong></a></li>';
	  }
	   if(!isset($_SESSION['utilisateur'])){
		echo "<li><a href='utilisateur/inscription.php'><strong>S'inscrire</strong></a></li>";
	   }
	  ?>
	  <li><a href="apropos.php"><strong>A propos du site</strong></a></li>
    </ul>
  </div>
</div>

<div class="corps">
<h2> Ton avis nous intéresse </h2>


<form method="post" action="evaluer.php">

	<p>
       <label for="region">Région de l'établissement</label><br />
       <select name="region" id="region">
         <option value="">Choisissez une région</option>
         <?php
         $bdd = new PDO('mysql:host=localhost;dbname=projet;charset=utf8','root','root');
     		 $rep = $bdd->query('select id_region, nom_region from region order by id_region asc');
     		 while($ligne = $rep -> fetch()) {
           echo '<option value="';
           echo $ligne['id_region'];
           echo '">';
           echo $ligne['nom_region'];
           echo '</option>';
           echo "\n";
         }
         $rep -> closeCursor();
          ?>
       </select>
   </p>

   <p>
       <label for="departement">Département de l'établissement</label><br />
       <select name="departement" id="departement">
				 <option value="">Choisissez un département</option>
         <?php
         $bdd = new PDO('mysql:host=localhost;dbname=projet;charset=utf8','root','root');
     		 $rep = $bdd->query('select id_departement, nom_departement, id_region from departement order by id_departement asc');
     		 while($ligne = $rep -> fetch()) {
           echo '<option value="';
           echo $ligne['id_departement'];
           echo '" class="';
					 echo $ligne['id_region'];
					 echo '">';
           echo $ligne['nom_departement'];
           echo '</option>';
           echo "\n";
         }
         $rep -> closeCursor();
          ?>
       </select>
   </p>
   <p>
       <label for="nom_eta">Nom de l'établissement</label><br />
       <select name="etablissement" id="etablissement">
				 <option value="">Choisissez un établissement</option>
				 <?php
				 $bdd = new PDO('mysql:host=localhost;dbname=projet;charset=utf8','root','root');
		 		 $rep = $bdd->query('select id_etablissement, nom_etablissement, id_departement from etablissement, commune where etablissement.id_commune = commune.id_commune');
		 		 while($ligne = $rep -> fetch()) {
					 echo '<option value="';
           echo $ligne['id_etablissement'];
           echo '" class="';
					 echo $ligne['id_departement'];
					 echo '">';
           echo $ligne['nom_etablissement'];
           echo '</option>';
           echo "\n";
				 }
				 $rep -> closeCursor();
				  ?>
       </select>

   </p>
   <p>
       <label for="appreciation">Evaluer l'infrastructure de l'établissement</label><br />
       <select name="infrastructure">
           <option value="5">Très satisfaisant</option>
					 <option value="4">Satisfaisant</option>
					 <option value="3">Moyen</option>
					 <option value="2">Peu satisfaisant</option>
					 <option value="1">Très peu satisfaisant</option>
					 <option value="0">Pas satisfait</option>
       </select>
   </p>


   <p>
       <label for="appreciation2">Evaluer la vie étudiante de l'établissement</label><br />
       <select name="vie_etudiante">
						 <option value="5">Très satisfaisant</option>
						 <option value="4">Satisfaisant</option>
						 <option value="3">Moyen</option>
						 <option value="2">Peu satisfaisant</option>
						 <option value="1">Très peu satisfaisant</option>
						 <option value="0">Pas satisfait</option>
       </select>



   </p>
	 <p>
			<label for="intitule_gd">Domaine</label><br />
			<select name="intitule_gd" id="intitule_gd">
				<option value="0"> Choisissez un domaine à évaluer</option>
				<?php
				$bdd = new PDO('mysql:host=localhost;dbname=projet;charset=utf8','root','root');
				$rep = $bdd->query('select id_grandediscipline, nom_grandediscipline from grandediscipline order by id_grandediscipline asc');
				while($ligne = $rep -> fetch()) {
					echo '<option value="';
					echo $ligne['id_grandediscipline'];
					echo '">';
					echo $ligne['nom_grandediscipline'];
					echo '</option>';
					echo "\n";
				}
				$rep -> closeCursor();
				 ?>
			</select>
	</p>

	<p>
			<label for="discipline">Filière</label>
		<br/>
			<select name="discipline" id="discipline">
				<option value=""> Choisissez une discipline à évaluer</option>
				<?php
				$bdd = new PDO('mysql:host=localhost;dbname=projet;charset=utf8','root','root');
				$rep = $bdd->query('select id_filiere, nom_filiere, id_grandediscipline from filiere order by id_filiere asc');
				while($ligne = $rep -> fetch()) {
					echo '<option value="';
					echo $ligne['id_filiere'];
					echo '" class="';
					echo $ligne['id_grandediscipline'];
					echo '">';
					echo $ligne['nom_filiere'];
					echo '</option>';
					echo "\n";
				}
				$rep -> closeCursor();
				 ?>
			</select>
	</p>
   <p>
       <label for="appreciation3">Evaluer la pédagogie globale au sein de la filière</label><br />
       <select name="pedagogie">
						 <option value="5">Très satisfaisant</option>
						 <option value="4">Satisfaisant</option>
						 <option value="3">Moyen</option>
						 <option value="2">Peu satisfaisant</option>
						 <option value="1">Très peu satisfaisant</option>
						 <option value="0">Pas satisfait</option>
       </select>
   </p>
	 <p>
		 <label for="commentaire"> Vos commentaires (facultatif)</label><br />
		 <textarea rows"1" name="commentaires">
		 </textarea>
	</p>
	 <p>
		 <input type="submit" value="Envoyer">
	</p>
</form>

</div>


<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="footer" class="clear">
    <!-- ####################################################################################################### -->
    <div class="fl_left clear">
      <div class="fl_left center">
	  <iframe width="250" height="250" frameborder="no" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.fr/maps?f=q&hl=fr&geocode=&q= 34 Route de Mende,34090 Montpellier&ie=UTF8&output=embed&s=AARTsJotOehFyV7Ld4EHPP1WtrZKl2G9Tw"></iframe>
	  </div>
      <address>
      34 Route de Mende<br />
      34090 Montpellier<br />
      France<br />
      <br />
      <strong>04 67 11 11 11</strong><br />
      Email: SearchYourUniversity@gmail.com
      </address>
    </div>
    <div id="copyright" class="clear">
      <p class="fl_left">Copyright &copy; 2017 - All Rights Reserved</p>
    </div>
    <!-- ####################################################################################################### -->
  </div>
</div>
</body>
</html>
