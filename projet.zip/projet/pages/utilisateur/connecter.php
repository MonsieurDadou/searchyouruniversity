<?php
  session_start()
 ?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="../../layout/styles/layout.css" type="text/css" />
<link rel="stylesheet" href="../../layout/styles/catalogue.css" type="text/css" />
<title>Connexion</title>
</head>
<body>
<div class="wrapper row1">
  <div id="topnav">
    <ul>
      <li><a href="index.php"><strong>Accueil</strong></a></li>
      <li><a href="../catalogue.php"><strong>Catalogue des universités</strong></a></li>
      <li><a href="../evaluation.php"><strong>Faire une évaluation</strong></a></li>
	  <?php
	  if(isset($_SESSION['utilisateur'])){
		echo '<li><a href="vosuniversites.php"><strong>Recherche guidée</strong></a></li>';
	  }
	  if(!isset($_SESSION['utilisateur'])){
		echo "<li><a href='inscription.php'><strong>S'inscrire</strong></a></li>";
	  }
	  ?>
	  <li><a href="../apropos.php"><strong>A propos du site</strong></a></li>
    </ul>
  </div>
</div>

<div class="corps">
</br>
</br>
      <?php
      function chercher($mail,$mdp){
        $bdd = new PDO('mysql:host=localhost;dbname=projet;charset=utf8','root','root');
        $rep = $bdd->query("select * from utilisateur where mail like '$mail' and motdepasse like '$mdp'");
        $ligne = $rep->fetch();
        $_SESSION['utilisateur'] = array('mail' => $ligne['mail'],'motdepasse' => $ligne['motdepasse'],'id_departement' => $ligne['id_departement'],'id_filiere' => $ligne['id_filiere']);
      }
        if($_POST['mail']==""){
          echo "<meta http-equiv=refresh content=3;URL=../../index.php?mail=".$_POST['mail'].">";
          echo "Champ du mail requis";
        }
        elseif($_POST['motdepasse']==""){
          echo "<meta http-equiv=refresh content=3;URL=../../index.php?mail=".$_POST['mail'].">";
          echo "Champ du mot de passe requis";
        }
        else {
          chercher($_POST['mail'],$_POST['motdepasse']);
          if($_SESSION['utilisateur']['mail']==""){
            echo "Le mail et le mot de passe ne correspondent pas.";
            session_destroy();
            echo "<meta http-equiv=refresh content=3;URL=../../index.php>";
          }
          else{
            echo "<meta http-equiv=refresh content=3;URL=../../index.php>";
            echo "Identification réussi. Bienvenue !";
          }
        }
      ?>
</div>	 	  
</body>
</html>
