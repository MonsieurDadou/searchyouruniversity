<?php
  session_start();
  ?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="../layout/styles/layout.css" type="text/css" />
<link rel="stylesheet" href="../layout/styles/catalogue.css" type="text/css" />
<title>Inscription</title>
</head>
<body>
<?php
function enrengistrer($mail, $motdepasse, $id_departement, $id_filiere){
  $bdd = new PDO('mysql:host=localhost;dbname=projet;charset=utf8','root','root');
  $rep = $bdd->query("INSERT INTO `projet`.`utilisateur` (`mail`, `motdepasse`, `id_departement`, `id_filiere`) VALUES ('$mail', '$motdepasse', '$id_departement', '$id_filiere')");
}
function connexion($mail , $motdepasse){
  $bdd = new PDO('mysql:host=localhost;dbname=projet;charset=utf8','root','root');
  $rep = $bdd->query("select * from utilisateur where mail like '$mail'");
  $ligne = $rep->fetch();
  $_SESSION['utilisateur'] = array('mail' => $ligne['mail'],'motdepasse' => $ligne['motdepasse'],'id_departement' => $ligne['id_departement'],'id_filiere' => $ligne['id_filiere']);
}

if($_POST['mail']==""){
  echo "<meta http-equiv=refresh content=1;URL=inscription.php>";
  echo "Champ du mail requis";
}
elseif($_POST['motdepasse']==""){
  echo "<meta http-equiv=refresh content=1;URL=inscription.php>";
  echo "Champ du mot de passe requis";
}
elseif($_POST['confirmdp']==""){
  echo "<meta http-equiv=refresh content=1;URL=inscription.php>";
  echo "Veuillez confirmer votre mot de passe";
}
elseif($_POST['motdepasse']!=$_POST['confirmdp']){
  echo "<meta http-equiv=refresh content=1;URL=inscription.php>";
  echo "Les deux mots de passes entrés sont différents";
}
else {
  enrengistrer($_POST['mail'],$_POST['motdepasse'],$_POST['dept2'],$_POST['discipline']);
  connexion($_POST['mail'],$_POST['motdepasse']);
  echo "<meta http-equiv=refresh content=3;URL=../../index.php>";
  echo "Inscription confirmée !";
}
if($_POST['mail']!=""){
	if (filter_var($_POST['mail'], FILTER_VALIDATE_EMAIL)) {
		echo ' Cet email est correct.';
	}else{
		echo ' Cet email a un format non adapté.';
	}
}
else{ echo "";}
?>
</table>
</body>
