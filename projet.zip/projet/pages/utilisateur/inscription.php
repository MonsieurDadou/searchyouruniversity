<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="../../layout/styles/layout.css" type="text/css" />
<link rel="stylesheet" href="../../layout/styles/catalogue.css" type="text/css" />
<title>Inscription</title>
<script type="text/javascript" src="../../layout/scripts/jquery.js"></script>
<script type="text/javascript" src="../../layout/scripts/jquery.chained.js"></script>
<script type="text/javascript">
$(function(){
    $("#dept1").chained("#region1");
});
$(function(){
    $("#dept2").chained("#region2");
});
$(function(){
    $("#discipline").chained("#intitule_gd");
});
</script>
</head>
<body>
<div class="wrapper row1">
  <div id="topnav">
    <ul>
      <li><a href="../../index.php"><strong>Accueil</strong></a></li>
      <li><a href="../catalogue.php"><strong>Catalogue des universités</strong></a></li>
      <li><a href="../evaluation.php"><strong>Faire une évaluation</strong></a></li>
	  <?php
	  if(isset($_SESSION['utilisateur'])){
		echo '<li><a href="vosuniversites.php"><strong>Recherche guidée</strong></a></li>';
	  }
	  if(!isset($_SESSION['utilisateur'])){
		echo "<li><a href='inscription.php'><strong>S'inscrire</strong></a></li>";
	  }
	  ?>
	  <li><a href="../apropos.php"><strong>A propos du site</strong></a></li>
    </ul>
  </div>
</div>



<div class="wrapper row2">
<div id="header" class="clear">
	<div class="fl_left">
      <h1>SearchYourUniversity</h1>
    </div>

</div>
</div>
<div class="corps">
  <!--
 <script>
		function test(a,b){

			var reg1 = document.getElementById(a);
			var reg2 = document.getElementById(b);
			reg2.value = reg1.value;
		}

		function test2(a,b){

			var dep1 = document.getElementById(a);
			var dep2 = document.getElementById(b);
			dep2.value = dep1.value;
		}

</script>
-->
<form method="post" action="inscrire.php">

   <fieldset>
       <legend>Informations générales</legend>

       <label for="mail">Votre email </label>
       <input type="text" name="mail" id="mail" />
	   <br>

       <label for="motdepasse"> Mot de passe </label>
       <input type="password" name="motdepasse" id="motdepasse" />
	   <br>
	   <label for="confirmdp"> Confirmation mot de passe </label>
       <input type="password" name="confirmdp" id="confirmdp" />
	   <br>

       <label for="niveau">Quel est votre niveau d'études ? (Licence, Master, Doctorat)</label>
       <input type="text" name="niveau" id="niveau" />
<br>
  <label for="intitule_gd">Domaine</label><br />
  <select name="intitule_gd" id="intitule_gd">
    <option value="0"> Indifférent </option>
    <?php
    $bdd = new PDO('mysql:host=localhost;dbname=projet;charset=utf8','root','root');
    $rep = $bdd->query('select id_grandediscipline, nom_grandediscipline from grandediscipline order by id_grandediscipline asc');
    while($ligne = $rep -> fetch()) {
      echo '<option value="';
      echo $ligne['id_grandediscipline'];
      echo '">';
      echo $ligne['nom_grandediscipline'];
      echo '</option>';
      echo "\n";
    }
    $rep -> closeCursor();
     ?>
  </select>


	   <br>

     <label for="discipline">Filière</label>
   <br/>
     <select name="discipline" id="discipline">
       <?php
       $bdd = new PDO('mysql:host=localhost;dbname=projet;charset=utf8','root','root');
       $rep = $bdd->query('select id_grandediscipline from filiere group by id_grandediscipline');
       while($ligne = $rep -> fetch()) {
         echo "<option value=0 class=".$ligne['id_grandediscipline']."> Indifférent </option>";
         echo "\n";
       }
       $rep -> closeCursor();
       $rep = $bdd->query('select id_filiere, nom_filiere, id_grandediscipline from filiere order by id_filiere asc');
       while($ligne = $rep -> fetch()) {
         echo '<option value="';
         echo $ligne['id_filiere'];
         echo '" class="';
         echo $ligne['id_grandediscipline'];
         echo '">';
         echo $ligne['nom_filiere'];
         echo '</option>';
         echo "\n";
       }
       $rep -> closeCursor();
        ?>
     </select>
 <br>



   </fieldset>


   <fieldset>
       <legend>Où habitez vous actuellement ?</legend>

<br>
  <label for="region">Région</label><br />
  <select name="region1" id="region1">
    <option value="0">Indifférent</option>
    <?php
    $bdd = new PDO('mysql:host=localhost;dbname=projet;charset=utf8','root','root');
    $rep = $bdd->query('select id_region, nom_region from region order by id_region asc');
    while($ligne = $rep -> fetch()) {
      echo '<option value="';
      echo $ligne['id_region'];
      echo '">';
      echo $ligne['nom_region'];
      echo '</option>';
      echo "\n";
    }
    $rep -> closeCursor();
     ?>
  </select>
<br>
  <label for="departement">Département</label><br />
  <select name="dept1" id="dept1">
    <?php
    $bdd = new PDO('mysql:host=localhost;dbname=projet;charset=utf8','root','root');
    $rep = $bdd->query('select id_region from departement group by id_region');
    while($ligne = $rep -> fetch()) {
      echo "<option value=0 class=".$ligne['id_region']."> Indifférent </option>";
      echo "\n";
    }
    $rep -> closeCursor();
    $rep = $bdd->query('select id_departement, nom_departement, id_region from departement order by id_departement asc');
    while($ligne = $rep -> fetch()) {
      echo '<option value="';
      echo $ligne['id_departement'];
      echo '" class="';
      echo $ligne['id_region'];
      echo '">';
      echo $ligne['nom_departement'];
      echo '</option>';
      echo "\n";
    }
    $rep -> closeCursor();
     ?>
  </select>
<br>





  </fieldset>


   <fieldset>
    <legend>Localisation de votre futur lieu d'étude</legend>
    <!--
	<INPUT type="radio" onchange="test('region1','region2');test2('dept1','dept2');" name="choix" value="I">Identique à votre lieu d'habitation<br />
	<INPUT type="radio" name="choix" value="D">Différent de votre lieu d'habitation<br />
-->

    <br>
      <label for="region">Région</label><br />
      <select name="region2" id="region2">
        <option value="0">Indifférent</option>
        <?php
        $bdd = new PDO('mysql:host=localhost;dbname=projet;charset=utf8','root','root');
        $rep = $bdd->query('select id_region, nom_region from region order by id_region asc');
        while($ligne = $rep -> fetch()) {
          echo '<option value="';
          echo $ligne['id_region'];
          echo '">';
          echo $ligne['nom_region'];
          echo '</option>';
          echo "\n";
        }
        $rep -> closeCursor();
         ?>
      </select>
    <br>
      <label for="departement">Département</label><br />
      <select name="dept2" id="dept2">
        <?php
        $bdd = new PDO('mysql:host=localhost;dbname=projet;charset=utf8','root','root');
        $rep = $bdd->query('select id_region from departement group by id_region');
        while($ligne = $rep -> fetch()) {
          echo "<option value=0 class=".$ligne['id_region']."> Indifférent </option>";
          echo "\n";
        }
        $rep -> closeCursor();
        $rep = $bdd->query('select id_departement, nom_departement, id_region from departement order by id_departement asc');
        while($ligne = $rep -> fetch()) {
          echo '<option value="';
          echo $ligne['id_departement'];
          echo '" class="';
          echo $ligne['id_region'];
          echo '">';
          echo $ligne['nom_departement'];
          echo '</option>';
          echo "\n";
        }
        $rep -> closeCursor();
         ?>
      </select>
    <br>
</fieldset>
<input type="submit" value="Envoyer" >
</form>

</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="footer" class="clear">
    <!-- ####################################################################################################### -->
    <div class="fl_left clear">
      <div class="fl_left center"><img src="../../images/worldmap.gif" alt="" /><br />
        <a href="#">Find Us With Google Maps &raquo;</a></div>
      <address>
      34 Route de Mende<br />
      34090 Montpellier<br />
      France<br />
      <br />
      <strong>04 67 11 11 11</strong><br />
      Email: SearchYourUniversity@gmail.com
      </address>
    </div>

    <div id="copyright" class="clear">
      <p class="fl_left">Copyright &copy; 2017 - All Rights Reserved</p>
    </div>
    <!-- ####################################################################################################### -->
  </div>
</div>



</body>
</html>
