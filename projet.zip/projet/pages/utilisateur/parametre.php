<?php
	session_start();
?>

<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="../../layout/styles/layout.css" type="text/css" />
<link rel="stylesheet" href="../../layout/styles/catalogue.css" type="text/css" />
<title>Paramètres</title>
</head>
<body>
<div class="wrapper row1">
  <div id="topnav">
    <ul>
      <li><a href="../../index.php"><strong>Accueil</strong></a></li>
      <li><a href="../catalogue.php"><strong>Catalogue des universités</strong></a></li>
      <li><a href="../evaluation.php"><strong>Faire une évaluation</strong></a></li>
	  <?php
	  if(isset($_SESSION['utilisateur'])){
		echo '<li><a href="vosuniversites.php"><strong>Recherche guidée</strong></a></li>';
	  }
	  if(!isset($_SESSION['utilisateur'])){
		echo "<li><a href='inscription.php'><strong>S'inscrire</strong></a></li>";
	  }
	  ?>
	  <li><a href="../apropos.php"><strong>A propos du site</strong></a></li> 
    </ul>
  </div>
</div>
<div class="wrapper row2">
  <div id="header" class="clear">
    <div class="fl_right">
	<?php
		if(isset($_SESSION['utilisateur'])){
			echo "Vous êtes connecté";
		
		}
	?>

	</div>
  </div>
</div>
<div class="corps">
		<?php
		if(isset($_SESSION['utilisateur'])){
			$bdd = new PDO('mysql:host=localhost;dbname=projet;charset=utf8','root','root');
			$rep = $bdd->query("SELECT departement.nom_departement, filiere.nom_filiere FROM departement, filiere, utilisateur WHERE departement.id_departement=utilisateur.id_departement AND filiere.id_filiere=utilisateur.id_filiere AND 
			utilisateur.mail='".$_SESSION['utilisateur']['mail']."'");
			$ligne = $rep->fetch();
			echo "Informations de votre compte"."<br>";
			echo "<br>";
			echo "Votre email: ".$_SESSION['utilisateur']['mail']."<br>";
			echo "<br>";
			echo "Nom  de votre département: ".$ligne['nom_departement']."<br>";
			echo "<br>";
			echo "Nom de votre filière: ".$ligne['nom_filiere']."<br>";
			echo "<br>";
			echo "Universités consultées: ";
			$bdd = new PDO('mysql:host=localhost;dbname=projet;charset=utf8','root','root');
			$rep = $bdd->query("SELECT * FROM historique WHERE historique.mail='".$_SESSION['utilisateur']['mail']."'");
			while($ligne = $rep->fetch()){
				echo "<br>";
				echo "-> ".$ligne['universite'];
			}
		}
		$rep ->closeCursor();
	?>
</div>

<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="footer" class="clear"> 
    <!-- ####################################################################################################### -->
    <div class="fl_left clear">
      <div class="fl_left center">
	  <iframe width="250" height="250" frameborder="no" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.fr/maps?f=q&hl=fr&geocode=&q= 34 Route de Mende,34090 Montpellier&ie=UTF8&output=embed&s=AARTsJotOehFyV7Ld4EHPP1WtrZKl2G9Tw"></iframe>
	  </div>
      <address>
      34 Route de Mende<br />
      34090 Montpellier<br />
      France<br />
      <br />
      <strong>04 67 11 11 11</strong><br />
      Email: SearchYourUniversity@gmail.com
      </address>
    </div>
 
    <div id="copyright" class="clear">
      <p class="fl_left">Copyright &copy; 2017 - All Rights Reserved</p>
    </div>
    <!-- ####################################################################################################### --> 
  </div>
</div>

</body>
</html>