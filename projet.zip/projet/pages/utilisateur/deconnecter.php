<?php
session_start();
session_destroy();
?>

<?php
echo "<meta http-equiv=refresh content=3;URL=../../index.php>";
echo "A bientôt !";
?>
