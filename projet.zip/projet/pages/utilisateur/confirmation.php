<?php
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="../../layout/styles/layout.css" type="text/css" />
<link rel="stylesheet" href="../../layout/styles/catalogue.css" type="text/css" />
<title>Confirmation inscription</title>
</head>
<body>
<div class="wrapper row1">
  <div id="topnav">
    <ul>
      <li><a href="index.php"><strong>Accueil</strong></a></li>
      <li><a href="../catalogue.php"><strong>Catalogue des universités</strong></a></li>
      <li><a href="../evaluation.php"><strong>Faire une évaluation</strong></a></li>
	  <?php
	  if(isset($_SESSION['utilisateur'])){
		echo '<li><a href="vosuniversites.php"><strong>Recherche guidée</strong></a></li>';
	  }
	  if(!isset($_SESSION['utilisateur'])){
		echo "<li><a href='inscription.php'><strong>S'inscrire</strong></a></li>";
	  }
	  ?>
	  <li><a href="../apropos.php"><strong>A propos du site</strong></a></li>
    </ul>
  </div>
</div>

<!-- ####################################################################################################### -->
<div class="wrapper row2">
  <div id="header" class="clear">
    <div class="fl_left">
      <h1>SearchYourUniversity</h1>
    </div>
    <div class="fl_right">
	  <form method="post" action="authentification.php">
		<p>
			<label for="pseudo">Identifiant :</label>
			<input type="text" name="pseudo" id="pseudo" />       
       <br />
			<label for="pass">Mot de passe :</label>
			<input type="password" name="motdepasse" id="pass" />       
		</p>			
	  </form>
          <form method="post" action="memoire.php">
		<p>
			<input type="checkbox" name="souvenir" id="souvenir" /> <label for="souvenir">Se souvenir de moi</label><br />
		</p>
		</form>	
	  <form action="mdpoublie.html">
			<input type="submit" value="Mot de passe oublié" >
          </form> 
    </div>
  </div>
</div>
<!-- ####################################################################################################### -->
<?php
session_start();
if ($_POST['mail']=="" || $_POST['motdepasse']==""|| $_POST['niveau']=="" || $_POST['intitule_gd']=="" || $_POST['discipline']==""|| $_POST['region1']=="" || $_POST['dept1']==""){
     echo "<META http-equiv='refresh' content='0; URL=inscription.php?mail=".$_POST['mail']."&niveau=".$_POST['niveau']."&domaine=".$_POST['intitule_gd']."&discipline=".$_POST['discipline']."&region=".$_POST['region1']."&departement=".$_POST['dept1']."'>";
}
else{	
	enregistrer($_POST['mail'], $_POST['motdepasse'], $_POST['dept1'], $_POST['discipline']);
	
	$bdd = new PDO('mysql:host=localhost;dbname=projet;charset=utf8','root', 'root'); 
	$req = "select * from utilisateur where mail='".$_POST['mail']."' and motdepasse='".$_POST['motdepasse']."'";
	$rep = $bdd->query($req);
	$ligne = $rep->fetch();
	$_SESSION['utilisateur'] = array('mail' => $ligne['mail'],'motdepasse' => $ligne['motdepasse'],'id_departement' => $ligne['id_departement'],'id_filiere' => $ligne['id_filiere']);
	$rep ->closeCursor();

	echo "<META http-equiv='refresh' content='0; URL=../../index.php'>";
	 
}
function enregistrer($mail,$motdepasse, $dept, $filiere){
	$bdd = new PDO('mysql:host=localhost;dbname=chez mireille;charset=utf8','root', 'root'); 
	// $req =$bdd->query( "select id_departement from departement where nom_departement='$dept'");
	// $ligne = $rep->fetch();
	// $iddept=$ligne['id_departement'];
	// $req = $bdd->query("select id_filiere from filiere where nom_filiere='$discipline'");
	// $ligne = $rep->fetch();
	// $idfiliere=$ligne['id_filiere'];
	$req = $bdd-> query("INSERT INTO `projet`.`utilisateur` (`mail`, `motdepasse`, `id_departement`, `id_filiere`) VALUES ('$mail', '$motdepasse', '$dept', '$filiere')");	
	
}

?>
<div class="corps">
	<p>Inscription terminée.</p><br>
	<p>Bienvenue chez SearchYourUniversity.</p>
</div>

<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="footer" class="clear"> 
    <!-- ####################################################################################################### -->
    <div class="fl_left clear">
      <div class="fl_left center">
	  <iframe width="250" height="250" frameborder="no" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.fr/maps?f=q&hl=fr&geocode=&q= 34 Route de Mende,34090 Montpellier&ie=UTF8&output=embed&s=AARTsJotOehFyV7Ld4EHPP1WtrZKl2G9Tw"></iframe>
	  </div>
      <address>
      34 Route de Mende<br />
      34090 Montpellier<br />
      France<br />
      <br />
      <strong>04 67 11 11 11</strong><br />
      Email: SearchYourUniversity@gmail.com
      </address>
    </div>
  
    <div id="copyright" class="clear">
      <p class="fl_left">Copyright &copy; 2017 - All Rights Reserved</p>
    </div>
    <!-- ####################################################################################################### --> 
  </div>
</div>
</body>
</html>