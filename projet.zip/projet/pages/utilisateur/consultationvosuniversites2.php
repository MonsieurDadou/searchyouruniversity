<?php
	session_start();
?>

<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="../../layout/styles/layout.css" type="text/css" />
<link rel="stylesheet" href="../../layout/styles/catalogue.css" type="text/css" />
<title>Consultation Université</title>
</head>
<body>
<div class="wrapper row1">
  <div id="topnav">
    <ul>
      <li><a href="../../index.php"><strong>Accueil</strong></a></li>
      <li><a href="../catalogue.php"><strong>Catalogue des universités</strong></a></li>
      <li><a href="../evaluation.php"><strong>Faire une évaluation</strong></a></li>
	   <?php
	  if(isset($_SESSION['utilisateur'])){
		echo '<li  class="active"><a href="vosuniversites.php"><strong>Recherche guidée</strong></a></li>';
	  }
	   if(!isset($_SESSION['utilisateur'])){
		echo "<li><a href='inscription.php'><strong>S'inscrire</strong></a></li>";
	   }
	  ?>
	  <li><a href="../apropos.php"><strong>A propos du site</strong></a></li>
    </ul>
  </div>
</div>

<div class="corps">
<div class="table">
	<?php
	function requete($region,$departement,$grandediscipline,$filiere){
	  if($region == "0"){
	    if($grandediscipline == "0"){
	      return("select etablissement.id_etablissement, etablissement.nom_etablissement, filiere.nom_filiere, master.nom_master, masteretablissement.nombre_de_reponses, masteretablissement.taux_de_reponse, masteretablissement.taux_insertion, masteretablissement.part_emplois_cadre_ou_profession_intermediaire, masteretablissement.part_des_emplois_stables, masteretablissement.part_des_emplois_a_temps_plein, masteretablissement.salaire_net_mensuel_median_des_emplois_a_temps_plein, masteretablissement.Q1_salaires_nets_mensuels_des_emplois_a_temps_plein, masteretablissement.Q3_salaires_nets_mensuels_des_emplois_a_temps_plein,masteretablissement.part_emplois_exterieurs_region, masteretablissement.part_femmes from etablissement, departement, region, commune, filiere, grandediscipline, masteretablissement, master where region.id_region = departement.id_region and departement.id_departement = commune.id_departement and commune.id_commune = etablissement.id_commune and filiere.id_grandediscipline = grandediscipline.id_grandediscipline AND  filiere.id_master = master.id_master AND master.id_master = masteretablissement.id_master AND masteretablissement.id_etablissement = etablissement.id_etablissement");
	    }
	    elseif($filiere == "0"){
	      return("select etablissement.id_etablissement, etablissement.nom_etablissement, filiere.nom_filiere, master.nom_master, masteretablissement.nombre_de_reponses, masteretablissement.taux_de_reponse, masteretablissement.taux_insertion, masteretablissement.part_emplois_cadre_ou_profession_intermediaire, masteretablissement.part_des_emplois_stables, masteretablissement.part_des_emplois_a_temps_plein, masteretablissement.salaire_net_mensuel_median_des_emplois_a_temps_plein, masteretablissement.Q1_salaires_nets_mensuels_des_emplois_a_temps_plein, masteretablissement.Q3_salaires_nets_mensuels_des_emplois_a_temps_plein,masteretablissement.part_emplois_exterieurs_region, masteretablissement.part_femmes from etablissement, departement, region, commune, filiere, grandediscipline, masteretablissement, master where region.id_region = departement.id_region and departement.id_departement = commune.id_departement and commune.id_commune = etablissement.id_commune and filiere.id_grandediscipline = grandediscipline.id_grandediscipline AND  filiere.id_master = master.id_master AND master.id_master = masteretablissement.id_master AND masteretablissement.id_etablissement = etablissement.id_etablissement AND grandediscipline.id_grandediscipline LIKE '".$grandediscipline."' ");
	    }
	    else{
	      return("select etablissement.id_etablissement, etablissement.nom_etablissement, filiere.nom_filiere, master.nom_master, masteretablissement.nombre_de_reponses, masteretablissement.taux_de_reponse, masteretablissement.taux_insertion, masteretablissement.part_emplois_cadre_ou_profession_intermediaire, masteretablissement.part_des_emplois_stables, masteretablissement.part_des_emplois_a_temps_plein, masteretablissement.salaire_net_mensuel_median_des_emplois_a_temps_plein, masteretablissement.Q1_salaires_nets_mensuels_des_emplois_a_temps_plein, masteretablissement.Q3_salaires_nets_mensuels_des_emplois_a_temps_plein,masteretablissement.part_emplois_exterieurs_region, masteretablissement.part_femmes from etablissement, departement, region, commune, filiere, grandediscipline, masteretablissement, master where region.id_region = departement.id_region and departement.id_departement = commune.id_departement and commune.id_commune = etablissement.id_commune and filiere.id_grandediscipline = grandediscipline.id_grandediscipline AND  filiere.id_master = master.id_master AND master.id_master = masteretablissement.id_master AND masteretablissement.id_etablissement = etablissement.id_etablissement AND grandediscipline.id_grandediscipline LIKE '".$grandediscipline."' AND filiere.id_filiere = '".$filiere."' ");
	    }
	  }
	  else{
	    if($departement == "0"){
	      if($grandediscipline == "0"){
	        return("select etablissement.id_etablissement, etablissement.nom_etablissement, filiere.nom_filiere, master.nom_master, masteretablissement.nombre_de_reponses, masteretablissement.taux_de_reponse, masteretablissement.taux_insertion, masteretablissement.part_emplois_cadre_ou_profession_intermediaire, masteretablissement.part_des_emplois_stables, masteretablissement.part_des_emplois_a_temps_plein, masteretablissement.salaire_net_mensuel_median_des_emplois_a_temps_plein, masteretablissement.Q1_salaires_nets_mensuels_des_emplois_a_temps_plein, masteretablissement.Q3_salaires_nets_mensuels_des_emplois_a_temps_plein,masteretablissement.part_emplois_exterieurs_region, masteretablissement.part_femmes from etablissement, departement, region, commune, filiere, grandediscipline, masteretablissement, master where region.id_region = departement.id_region and departement.id_departement = commune.id_departement and commune.id_commune = etablissement.id_commune and filiere.id_grandediscipline = grandediscipline.id_grandediscipline AND  filiere.id_master = master.id_master AND master.id_master = masteretablissement.id_master AND masteretablissement.id_etablissement = etablissement.id_etablissement AND region.id_region LIKE '".$region."'");
	      }
	      elseif($filiere == "0"){
	        return("select etablissement.id_etablissement, etablissement.nom_etablissement, filiere.nom_filiere, master.nom_master, masteretablissement.nombre_de_reponses, masteretablissement.taux_de_reponse, masteretablissement.taux_insertion, masteretablissement.part_emplois_cadre_ou_profession_intermediaire, masteretablissement.part_des_emplois_stables, masteretablissement.part_des_emplois_a_temps_plein, masteretablissement.salaire_net_mensuel_median_des_emplois_a_temps_plein, masteretablissement.Q1_salaires_nets_mensuels_des_emplois_a_temps_plein, masteretablissement.Q3_salaires_nets_mensuels_des_emplois_a_temps_plein,masteretablissement.part_emplois_exterieurs_region, masteretablissement.part_femmes from etablissement, departement, region, commune, filiere, grandediscipline, masteretablissement, master where region.id_region = departement.id_region and departement.id_departement = commune.id_departement and commune.id_commune = etablissement.id_commune and filiere.id_grandediscipline = grandediscipline.id_grandediscipline AND  filiere.id_master = master.id_master AND master.id_master = masteretablissement.id_master AND masteretablissement.id_etablissement = etablissement.id_etablissement AND region.id_region LIKE '".$region."' AND grandediscipline.id_grandediscipline LIKE '".$grandediscipline."'");
	      }
	      else{
	        return("select etablissement.id_etablissement, etablissement.nom_etablissement, filiere.nom_filiere, master.nom_master, masteretablissement.nombre_de_reponses, masteretablissement.taux_de_reponse, masteretablissement.taux_insertion, masteretablissement.part_emplois_cadre_ou_profession_intermediaire, masteretablissement.part_des_emplois_stables, masteretablissement.part_des_emplois_a_temps_plein, masteretablissement.salaire_net_mensuel_median_des_emplois_a_temps_plein, masteretablissement.Q1_salaires_nets_mensuels_des_emplois_a_temps_plein, masteretablissement.Q3_salaires_nets_mensuels_des_emplois_a_temps_plein,masteretablissement.part_emplois_exterieurs_region, masteretablissement.part_femmes from etablissement, departement, region, commune, filiere, grandediscipline, masteretablissement, master where region.id_region = departement.id_region and departement.id_departement = commune.id_departement and commune.id_commune = etablissement.id_commune and filiere.id_grandediscipline = grandediscipline.id_grandediscipline AND  filiere.id_master = master.id_master AND master.id_master = masteretablissement.id_master AND masteretablissement.id_etablissement = etablissement.id_etablissement AND region.id_region LIKE '".$region."' AND grandediscipline.id_grandediscipline LIKE '".$grandediscipline."' AND filiere.id_filiere = '".$filiere."' ");
	      }
	    }
	    else{
	      if($grandediscipline == "0"){
	        return("select etablissement.id_etablissement, etablissement.nom_etablissement, filiere.nom_filiere, master.nom_master, masteretablissement.nombre_de_reponses, masteretablissement.taux_de_reponse, masteretablissement.taux_insertion, masteretablissement.part_emplois_cadre_ou_profession_intermediaire, masteretablissement.part_des_emplois_stables, masteretablissement.part_des_emplois_a_temps_plein, masteretablissement.salaire_net_mensuel_median_des_emplois_a_temps_plein, masteretablissement.Q1_salaires_nets_mensuels_des_emplois_a_temps_plein, masteretablissement.Q3_salaires_nets_mensuels_des_emplois_a_temps_plein,masteretablissement.part_emplois_exterieurs_region, masteretablissement.part_femmes from etablissement, departement, region, commune, filiere, grandediscipline, masteretablissement, master where region.id_region = departement.id_region and departement.id_departement = commune.id_departement and commune.id_commune = etablissement.id_commune and filiere.id_grandediscipline = grandediscipline.id_grandediscipline AND  filiere.id_master = master.id_master AND master.id_master = masteretablissement.id_master AND masteretablissement.id_etablissement = etablissement.id_etablissement AND region.id_region LIKE '".$region."' AND departement.id_departement LIKE '".$departement."'");
	      }
	      elseif($filiere == "0"){
	        return("select etablissement.id_etablissement, etablissement.nom_etablissement, filiere.nom_filiere, master.nom_master, masteretablissement.nombre_de_reponses, masteretablissement.taux_de_reponse, masteretablissement.taux_insertion, masteretablissement.part_emplois_cadre_ou_profession_intermediaire, masteretablissement.part_des_emplois_stables, masteretablissement.part_des_emplois_a_temps_plein, masteretablissement.salaire_net_mensuel_median_des_emplois_a_temps_plein, masteretablissement.Q1_salaires_nets_mensuels_des_emplois_a_temps_plein, masteretablissement.Q3_salaires_nets_mensuels_des_emplois_a_temps_plein,masteretablissement.part_emplois_exterieurs_region, masteretablissement.part_femmes from etablissement, departement, region, commune, filiere, grandediscipline, masteretablissement, master where region.id_region = departement.id_region and departement.id_departement = commune.id_departement and commune.id_commune = etablissement.id_commune and filiere.id_grandediscipline = grandediscipline.id_grandediscipline AND  filiere.id_master = master.id_master AND master.id_master = masteretablissement.id_master AND masteretablissement.id_etablissement = etablissement.id_etablissement AND region.id_region LIKE '".$region."' AND departement.id_departement LIKE '".$departement."' AND grandediscipline.id_grandediscipline LIKE '".$grandediscipline."'");
	      }
	      else{
	        return("select etablissement.id_etablissement, etablissement.nom_etablissement, filiere.nom_filiere, master.nom_master, masteretablissement.nombre_de_reponses, masteretablissement.taux_de_reponse, masteretablissement.taux_insertion, masteretablissement.part_emplois_cadre_ou_profession_intermediaire, masteretablissement.part_des_emplois_stables, masteretablissement.part_des_emplois_a_temps_plein, masteretablissement.salaire_net_mensuel_median_des_emplois_a_temps_plein, masteretablissement.Q1_salaires_nets_mensuels_des_emplois_a_temps_plein, masteretablissement.Q3_salaires_nets_mensuels_des_emplois_a_temps_plein,masteretablissement.part_emplois_exterieurs_region, masteretablissement.part_femmes from etablissement, departement, region, commune, filiere, grandediscipline, masteretablissement, master where region.id_region = departement.id_region and departement.id_departement = commune.id_departement and commune.id_commune = etablissement.id_commune and filiere.id_grandediscipline = grandediscipline.id_grandediscipline AND  filiere.id_master = master.id_master AND master.id_master = masteretablissement.id_master AND masteretablissement.id_etablissement = etablissement.id_etablissement AND region.id_region LIKE '".$region."' AND departement.id_departement LIKE '".$departement."' AND grandediscipline.id_grandediscipline LIKE '".$grandediscipline."' AND filiere.id_filiere = '".$filiere."' ");
	      }
	    }
	  }
	}

function comparaison($filiere){
	$bdd = new PDO('mysql:host=localhost;dbname=projet;charset=utf8','root','root');
	$rep2 = $bdd->query("select master.taux_insertion,master.part_emplois_cadre_ou_profession_intermediaire,master.part_des_emplois_stables,master.part_des_emplois_a_temps_plein,master.salaire_net_mensuel_median_des_emplois_a_temps_plein,master.Q1_salaires_nets_mensuels_des_emplois_a_temps_plein,master.Q3_salaires_nets_mensuels_des_emplois_a_temps_plein,master.part_des_emplois_situes_en_dehors_de_la_region,master.part_femmes from master where master.nom_master like '".$filiere."'");
	$ligne2 = $rep2 -> fetch();
	$comparaison = array("taux_insertion" => $ligne2['taux_insertion'],"cadre_intermediaire" => $ligne2['part_emplois_cadre_ou_profession_intermediaire'],"stable" => $ligne2['part_des_emplois_stables'], "plein" => $ligne2['part_des_emplois_a_temps_plein'],"salaire_net" => $ligne2['salaire_net_mensuel_median_des_emplois_a_temps_plein'], "Q1" => $ligne2['Q1_salaires_nets_mensuels_des_emplois_a_temps_plein'], "Q3" => $ligne2['Q3_salaires_nets_mensuels_des_emplois_a_temps_plein'],"exterieur"=> $ligne2['part_des_emplois_situes_en_dehors_de_la_region'], "part_femmes" => $ligne2['part_femmes']);
	return $comparaison;
}
/*
function requete ($region,$departement,$grandediscipline,$filiere){
  return("select etablissement.nom_etablissement, commune.nom_commune, departement.nom_departement, region.nom_region, filiere.nom_filiere, grandediscipline.nom_grandediscipline from etablissement, departement, region, departementregion, commune, communeetablissement, communedepartement, filiere, grandediscipline, grandedisciplinefiliere where etablissement.id_etablissement = communeetablissement.id_etablissement AND communeetablissement.id_commune = commune.id_commune AND commune.id_commune = communedepartement.id_commune AND communedepartement.id_departement = departement.id_departement AND departement.id_departement = departementregion.id_departement AND departementregion.id_region = region.id_region AND grandediscipline.id_grandediscipline = grandedisciplinefiliere.id_grandediscipline AND grandedisciplinefiliere.id_filiere = filiere.id_filiere AND region.id_region LIKE '".$region."' AND departement.id_departement LIKE '".$departement."' AND grandediscipline.id_grandediscipline LIKE '".$grandediscipline."' AND filiere.id_filiere = '".$filiere."' ");
}
*/
/*
function requete($region,$departement,$grandediscipline,$filiere){
  if($region == "0"){
    echo ($grandediscipline);
    if($grandediscipline == "0"){
      return($grandediscipline);
    }
    elseif($filiere == "0"){
      return("REGION = 0, f = 0");
    }
    else{
      return("REGION = 0");
    }
  }
  else{
    if($departement == "0"){
      if($grandediscipline == "0"){
        return("D = 0, GD = 0");
      }
      elseif($filiere == "0"){
        return("D = 0, f = 0");
      }
      else{
        return("D = 0");
      }
    }
    else{
      if($grandediscipline == "0"){
        return("GD = 0");
      }
      elseif($filiere == "0"){
        return("GD = 0, F = 0");
      }
      else{
        return("ok");
        }
      }
    }
  }
  */
echo "<h1> Comparaison nationale </h1>";
echo "<table>";
echo "\n";
echo "<tr>";
echo "\n";
echo "<th>Etablissement</th>";
echo "\n";
echo "<th>Possible master</th>";
echo "\n";
echo"<th>Nombre de réponses</th>";
echo "\n";
echo"<th>Taux de réponse</th>";
echo "\n";
echo "<th>Taux d'insertion</th>";
echo "\n";
echo "<th>Part d'emplois cadre ou profession intermédiaire</th>";
echo "\n";
echo "<th>Part des emplois stables</th>";
echo "\n";
echo "<th>Part des emplois à temps plein</th>";
echo "\n";
echo "<th>Salaire mensuel net median</th>";
echo "\n";
echo "<th>1er quartile des salaires net mensuels</th>";
echo "\n";
echo "<th>3er quartile des salaires net mensuels</th>";
echo "\n";
echo "<th>Part des emplois à l'extérieur de la région</th>";
echo "\n";
echo "<th>Part de femmes</th>";
echo "</tr>";
$bdd = new PDO('mysql:host=localhost;dbname=projet;charset=utf8','root','root');
$rep = $bdd->query(requete($_GET['region'],$_GET['departement'],$_GET['intitule_gd'],$_GET['discipline']));
while($ligne = $rep -> fetch()) {
	$comparaison = comparaison($ligne['nom_master']);
	echo "<tr>";
	echo "<td>";
	echo "<a href='../universites.php?id_etablissement=".$ligne['id_etablissement']."'>".$ligne['nom_etablissement']."</a></td>\n" ;
	echo "</td>";
	echo "\n";
	echo "<td>";
	echo $ligne['nom_master'];
  echo "</td>";
  echo "\n";
  echo "<td>";
  echo $ligne['nombre_de_reponses'];
  echo "</td>";
  echo "\n";
  echo "<td>";
  echo $ligne['taux_de_reponse'];
  echo "</td>";
  echo "\n";
  echo "<td>";
	echo $ligne['taux_insertion'] - $comparaison['taux_insertion'] ;
  echo "</td>";
  echo "\n";
  echo "<td>";
  echo $ligne['part_emplois_cadre_ou_profession_intermediaire'] - $comparaison['cadre_intermediaire'];
  echo "</td>";
  echo "\n";
  echo "<td>";
  echo $ligne['part_des_emplois_stables'] - $comparaison['stable'];
  echo "</td>";
  echo "\n";
  echo "<td>";
  echo $ligne['part_des_emplois_a_temps_plein'] - $comparaison['plein'];
  echo "</td>";
  echo "\n";
  echo "<td>";
  echo $ligne['salaire_net_mensuel_median_des_emplois_a_temps_plein'] - $comparaison['salaire_net'];
  echo "</td>";
  echo "\n";
  echo "<td>";
  echo $ligne['Q1_salaires_nets_mensuels_des_emplois_a_temps_plein'] - $comparaison['Q1'];
  echo "</td>";
  echo "\n";
  echo "<td>";
  echo $ligne['Q3_salaires_nets_mensuels_des_emplois_a_temps_plein'] - $comparaison['Q3'];
  echo "</td>";
  echo "\n";
  echo "<td>";
  echo $ligne['part_emplois_exterieurs_region'] - $comparaison['exterieur'];
  echo "</td>";
  echo "\n";
  echo "<td>";
  echo $ligne['part_femmes'] - $comparaison['part_femmes'];
  echo "</td>";
  echo "\n";
  echo "</tr>";
  echo "\n";
}
$rep -> closeCursor();
?>
</table>
<br/n>
<form action="consultationvosuniversites.php" method="get">
	<input type="hidden" name="region" value="<?php echo $_GET['region'];?>">
	<input type="hidden" name="departement" value="<?php echo $_GET['departement'];?>">
	<input type="hidden" name="intitule_gd" value="<?php echo $_GET['intitule_gd'];?>">
	<input type="hidden" name="discipline" value="<?php echo $_GET['discipline'];?>">
<input type="submit" value="Retour" >
</form>
</div>
</div>



<div class="wrapper">
  <div id="footer" class="clear">
    <!-- ####################################################################################################### -->
    <div class="fl_left clear">
      <div class="fl_left center">
	  <iframe width="250" height="250" frameborder="no" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.fr/maps?f=q&hl=fr&geocode=&q= 34 Route de Mende,34090 Montpellier&ie=UTF8&output=embed&s=AARTsJotOehFyV7Ld4EHPP1WtrZKl2G9Tw"></iframe>
	  </div>
      <address>
      34 Route de Mende<br />
      34090 Montpellier<br />
      France<br />
      <br />
      <strong>04 67 11 11 11</strong><br />
      Email: SearchYourUniversity@gmail.com
      </address>
    </div>

    <div id="copyright" class="clear">
      <p class="fl_left">Copyright &copy; 2017 - All Rights Reserved</p>
    </div>
    <!-- ####################################################################################################### -->
  </div>
</div>
</body>
</html>
