<?php
	session_start();
?>

<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="../layout/styles/layout.css" type="text/css" />
<link rel="stylesheet" href="../layout/styles/catalogue.css" type="text/css" />
<title>Consultation Catalogue</title>
</head>
<body>
<div class="wrapper row1">
  <div id="topnav">
    <ul>
      <li><a href="../index.php"><strong>Accueil</strong></a></li>
      <li class="active"><a href="catalogue.php"><strong>Catalogue des universités</strong></a></li>
      <li><a href="evaluation.php"><strong>Faire une évaluation</strong></a></li>
	   <?php
	  if(isset($_SESSION['utilisateur'])){
		echo '<li><a href="utilisateur/vosuniversites.php"><strong>Recherche guidée</strong></a></li>';
	  }
	   if(!isset($_SESSION['utilisateur'])){
		echo "<li><a href='utilisateur/inscription.php'><strong>S'inscrire</strong></a></li>";
	   }
	  ?>
	  <li><a href="apropos.php"><strong>A propos du site</strong></a></li>
    </ul>
  </div>
</div>

<div class="corps">
<?php
function requete($region,$departement,$grandediscipline,$filiere){
  if($region == "0"){
    if($grandediscipline == "0"){
      return("select etablissement.id_etablissement,etablissement.nom_etablissement, commune.nom_commune, departement.nom_departement, region.nom_region, filiere.nom_filiere, grandediscipline.nom_grandediscipline from etablissement, commune, departement, region, filiere, grandediscipline where region.id_region = departement.id_region and departement.id_departement = commune.id_departement and commune.id_commune = etablissement.id_commune and filiere.id_grandediscipline = grandediscipline.id_grandediscipline");
    }
    elseif($filiere == "0"){
      return("select etablissement.id_etablissement,etablissement.nom_etablissement, commune.nom_commune, departement.nom_departement, region.nom_region, filiere.nom_filiere, grandediscipline.nom_grandediscipline from etablissement, commune, departement, region, filiere, grandediscipline where region.id_region = departement.id_region and departement.id_departement = commune.id_departement and commune.id_commune = etablissement.id_commune and filiere.id_grandediscipline = grandediscipline.id_grandediscipline AND grandediscipline.id_grandediscipline LIKE '".$grandediscipline."' ");
    }
    else{
      return("select etablissement.id_etablissement,etablissement.nom_etablissement, commune.nom_commune, departement.nom_departement, region.nom_region, filiere.nom_filiere, grandediscipline.nom_grandediscipline from etablissement, commune, departement, region, filiere, grandediscipline where region.id_region = departement.id_region and departement.id_departement = commune.id_departement and commune.id_commune = etablissement.id_commune and filiere.id_grandediscipline = grandediscipline.id_grandediscipline AND grandediscipline.id_grandediscipline LIKE '".$grandediscipline."' AND filiere.id_filiere = '".$filiere."' ");
    }
  }
  else{
    if($departement == "0"){
      if($grandediscipline == "0"){
        return("select etablissement.id_etablissement,etablissement.nom_etablissement, commune.nom_commune, departement.nom_departement, region.nom_region, filiere.nom_filiere, grandediscipline.nom_grandediscipline from etablissement, commune, departement, region, filiere, grandediscipline where region.id_region = departement.id_region and departement.id_departement = commune.id_departement and commune.id_commune = etablissement.id_commune and filiere.id_grandediscipline = grandediscipline.id_grandediscipline AND region.id_region LIKE '".$region."'");
      }
      elseif($filiere == "0"){
        return("select etablissement.id_etablissement,etablissement.nom_etablissement, commune.nom_commune, departement.nom_departement, region.nom_region, filiere.nom_filiere, grandediscipline.nom_grandediscipline from etablissement, commune, departement, region, filiere, grandediscipline where region.id_region = departement.id_region and departement.id_departement = commune.id_departement and commune.id_commune = etablissement.id_commune and filiere.id_grandediscipline = grandediscipline.id_grandediscipline AND region.id_region LIKE '".$region."' AND grandediscipline.id_grandediscipline LIKE '".$grandediscipline."'");
      }
      else{
        return("select etablissement.id_etablissement,etablissement.nom_etablissement, commune.nom_commune, departement.nom_departement, region.nom_region, filiere.nom_filiere, grandediscipline.nom_grandediscipline from etablissement, commune, departement, region, filiere, grandediscipline where region.id_region = departement.id_region and departement.id_departement = commune.id_departement and commune.id_commune = etablissement.id_commune and filiere.id_grandediscipline = grandediscipline.id_grandediscipline AND region.id_region LIKE '".$region."' AND grandediscipline.id_grandediscipline LIKE '".$grandediscipline."' AND filiere.id_filiere = '".$filiere."' ");
      }
    }
    else{
      if($grandediscipline == "0"){
        return("select etablissement.id_etablissement,etablissement.nom_etablissement, commune.nom_commune, departement.nom_departement, region.nom_region, filiere.nom_filiere, grandediscipline.nom_grandediscipline from etablissement, commune, departement, region, filiere, grandediscipline where region.id_region = departement.id_region and departement.id_departement = commune.id_departement and commune.id_commune = etablissement.id_commune and filiere.id_grandediscipline = grandediscipline.id_grandediscipline AND region.id_region LIKE '".$region."' AND departement.id_departement LIKE '".$departement."'");
      }
      elseif($filiere == "0"){
        return("select etablissement.id_etablissement,etablissement.nom_etablissement, commune.nom_commune, departement.nom_departement, region.nom_region, filiere.nom_filiere, grandediscipline.nom_grandediscipline from etablissement, commune, departement, region, filiere, grandediscipline where region.id_region = departement.id_region and departement.id_departement = commune.id_departement and commune.id_commune = etablissement.id_commune and filiere.id_grandediscipline = grandediscipline.id_grandediscipline AND region.id_region LIKE '".$region."' AND departement.id_departement LIKE '".$departement."' AND grandediscipline.id_grandediscipline LIKE '".$grandediscipline."'");
      }
      else{
        return("select etablissement.id_etablissement,etablissement.nom_etablissement, commune.nom_commune, departement.nom_departement, region.nom_region, filiere.nom_filiere, grandediscipline.nom_grandediscipline from etablissement, commune, departement, region, filiere, grandediscipline where region.id_region = departement.id_region and departement.id_departement = commune.id_departement and commune.id_commune = etablissement.id_commune and filiere.id_grandediscipline = grandediscipline.id_grandediscipline AND region.id_region LIKE '".$region."' AND departement.id_departement LIKE '".$departement."' AND grandediscipline.id_grandediscipline LIKE '".$grandediscipline."' AND filiere.id_filiere = '".$filiere."' ");
      }
    }
  }
}
/*
function requete ($region,$departement,$grandediscipline,$filiere){
  return("select etablissement.nom_etablissement, commune.nom_commune, departement.nom_departement, region.nom_region, filiere.nom_filiere, grandediscipline.nom_grandediscipline from etablissement, departement, region, departementregion, commune, communeetablissement, communedepartement, filiere, grandediscipline, grandedisciplinefiliere where etablissement.id_etablissement = communeetablissement.id_etablissement AND communeetablissement.id_commune = commune.id_commune AND commune.id_commune = communedepartement.id_commune AND communedepartement.id_departement = departement.id_departement AND departement.id_departement = departementregion.id_departement AND departementregion.id_region = region.id_region AND grandediscipline.id_grandediscipline = grandedisciplinefiliere.id_grandediscipline AND grandedisciplinefiliere.id_filiere = filiere.id_filiere AND region.id_region LIKE '".$region."' AND departement.id_departement LIKE '".$departement."' AND grandediscipline.id_grandediscipline LIKE '".$grandediscipline."' AND filiere.id_filiere = '".$filiere."' ");
}
*/
/*
function requete($region,$departement,$grandediscipline,$filiere){
  if($region == "0"){
    echo ($grandediscipline);
    if($grandediscipline == "0"){
      return($grandediscipline);
    }
    elseif($filiere == "0"){
      return("REGION = 0, f = 0");
    }
    else{
      return("REGION = 0");
    }
  }
  else{
    if($departement == "0"){
      if($grandediscipline == "0"){
        return("D = 0, GD = 0");
      }
      elseif($filiere == "0"){
        return("D = 0, f = 0");
      }
      else{
        return("D = 0");
      }
    }
    else{
      if($grandediscipline == "0"){
        return("GD = 0");
      }
      elseif($filiere == "0"){
        return("GD = 0, F = 0");
      }
      else{
        return("ok");
        }
      }
    }
  }
  */
echo "<table class='table'>";
echo "\n";
echo "<tr>";
echo "\n";
echo "<th>Etablissement</th>";
echo "\n";
echo "<th>Region</th>";
echo "\n";
echo"<th>Departement</th>";
echo "\n";
echo"<th>Commune</th>";
echo "\n";
echo "<th>Grande Discipline</th>";
echo "\n";
echo "<th>Filière</th>";
echo "</tr>";
$bdd = new PDO('mysql:host=localhost;dbname=projet;charset=utf8','root','root');
$rep = $bdd->query(requete($_POST['region'],$_POST['departement'],$_POST['intitule_gd'],$_POST['discipline']));
while($ligne = $rep -> fetch()) {
  echo "<tr>";
  echo "<td>";
  if(isset($_SESSION['utilisateur'])){
	echo "<a href='universites.php?id_etablissement=".$ligne['id_etablissement']."'>".$ligne['nom_etablissement']."</a></td>\n" ;
  }
  else{
	  echo $ligne['nom_etablissement'];
	  //echo "<a href='universites.php?id_etablissement=".$ligne['id_etablissement']."'>".$ligne['nom_etablissement']."</a></td>\n" ;
  }
  echo "</td>";
  echo "\n";
  echo "<td>";
  echo $ligne['nom_region'];
  echo "</td>";
  echo "\n";
  echo "<td>";
  echo $ligne['nom_departement'];
  echo "</td>";
  echo "\n";
  echo "<td>";
  echo $ligne['nom_commune'];
  echo "</td>";
  echo "\n";
  echo "<td>";
  echo $ligne['nom_grandediscipline'];
  echo "</td>";
  echo "\n";
  echo "<td>";
  echo $ligne['nom_filiere'];
  echo "</td>";
  echo "\n";
  echo "</tr>";
  echo "\n";
}

$rep -> closeCursor();
?>
</table>

</div>



<div class="wrapper">
  <div id="footer" class="clear">
    <!-- ####################################################################################################### -->
    <div class="fl_left clear">
      <div class="fl_left center">
	  <iframe width="250" height="250" frameborder="no" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.fr/maps?f=q&hl=fr&geocode=&q= 34 Route de Mende,34090 Montpellier&ie=UTF8&output=embed&s=AARTsJotOehFyV7Ld4EHPP1WtrZKl2G9Tw"></iframe>
	  </div>
      <address>
      34 Route de Mende<br />
      34090 Montpellier<br />
      France<br />
      <br />
      <strong>04 67 11 11 11</strong><br />
      Email: SearchYourUniversity@gmail.com
      </address>
    </div>

    <div id="copyright" class="clear">
      <p class="fl_left">Copyright &copy; 2017 - All Rights Reserved</p>
    </div>
    <!-- ####################################################################################################### -->
  </div>
</div>
</body>
</html>
