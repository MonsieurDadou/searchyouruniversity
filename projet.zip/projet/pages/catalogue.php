<?php
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="../layout/styles/layout.css" type="text/css" />
<link rel="stylesheet" href="../layout/styles/catalogue.css" type="text/css" />
<title>Catalogue</title>
<script type="text/javascript" src="../layout/scripts/jquery.js"></script>
<script type="text/javascript" src="../layout/scripts/jquery.chained.js"></script>
<script type="text/javascript">
$(function(){
    $("#departement").chained("#region");
});
$(function(){
    $("#discipline").chained("#intitule_gd");
});
</script>
</head>
<body>
<div class="wrapper row1">
  <div id="topnav">
    <ul>
      <li><a href="../index.php"><strong>Accueil</strong></a></li>
      <li class="active"><a href="catalogue.php"><strong>Catalogue des universités</strong></a></li>
      <li><a href="evaluation.php"><strong>Faire une évaluation</strong></a></li>
	  <?php
	  if(isset($_SESSION['utilisateur'])){
		echo '<li><a href="utilisateur/vosuniversites.php"><strong>Recherche guidée</strong></a></li>';
	  }
	   if(!isset($_SESSION['utilisateur'])){
		echo "<li><a href='utilisateur/inscription.php'><strong>S'inscrire</strong></a></li>";
	   }
	  ?>
	  <li><a href="apropos.php"><strong>A propos du site</strong></a></li>
    </ul>
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper row2">
  <div id="header" class="clear">
    <div class="fl_left">
      <h1>SearchYourUniversity</h1>
    </div>
	<?php
		if(isset($_SESSION['utilisateur'])){
			echo '<div class="fl_right">';
			echo "<br/>";
			echo "<br/>";
			echo '<p> Vous êtes connecté </p>';
			echo '<form action="utilisateur/parametre.php" method="post" autocomplete="off">';
			echo '<input type="submit" value="Vos informations">';
			echo '</form>';
			echo "<br/>";
			echo "\n";
			echo '<form action="utilisateur/deconnecter.php" method="post" autocomplete="off">';
			echo '<input type="submit" value="Se deconnecter">';
			echo '</form>';
		}
		else{
			echo '<div class="fl_right">';
			echo "\n";
		  echo '<form action="utilisateur/connecter.php" method="post" autocomplete="off">';
			echo "\n";
			echo '<p>';
			echo "\n";
			echo '<label for="pseudo">Adresse mail :</label>';
			echo "\n";
			echo '<input type="text" name="mail" id="mail" />';
			echo "\n";
			echo '<br />';
			echo '<label for="pass">Mot de passe :</label>';
			echo "\n";
			echo '<input type="password" name="motdepasse" id="motdepasse" />';
			echo "\n";
			echo '</p>';
			echo "\n";
			echo '<input type="checkbox" name="souvenir" id="souvenir" /> <label for="souvenir">Se souvenir de moi</label><br />';
			echo "\n";
			echo '<input type="submit" value="Se connecter">';
			echo "\n";
		  echo '</form>';
			echo "\n";
			echo '<form method="post" action="memoire.php">';
			echo "\n";
			echo '<p>';
			echo "\n";
			echo '</p>';
			echo "\n";
		  echo '</form>';
			echo "\n";
		  echo '<form action="utilisateur/mdpoublie.html">';
			echo "\n";
			echo '<input type="submit" value="Mot de passe oublié" >';
			echo "\n";
			echo '</form>';
			echo "\n";
			echo '</div>';
			echo "\n";
		}
		?>
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="corps">

<form action="consultationcatalogue.php" method="post">
	<p>
       <label for="region">Région</label><br />
       <select name="region" id="region">
         <option value="0">Indifférent</option>
         <?php
         $bdd = new PDO('mysql:host=localhost;dbname=projet;charset=utf8','root','root');
     		 $rep = $bdd->query('select id_region, nom_region from region order by id_region asc');
     		 while($ligne = $rep -> fetch()) {
           echo '<option value="';
           echo $ligne['id_region'];
           echo '">';
           echo $ligne['nom_region'];
           echo '</option>';
           echo "\n";
         }
         $rep -> closeCursor();
          ?>
       </select>
   </p>

   <p>
       <label for="departement">Département</label><br />
       <select name="departement" id="departement">
         <?php
         $bdd = new PDO('mysql:host=localhost;dbname=projet;charset=utf8','root','root');
				 $rep = $bdd->query('select id_region from departement group by id_region');
				 while($ligne = $rep -> fetch()) {
					 echo "<option value=0 class=".$ligne['id_region']."> Indifférent </option>";
					 echo "\n";
				 }
				 $rep -> closeCursor();
     		 $rep = $bdd->query('select id_departement, nom_departement, id_region from departement order by id_departement asc');
     		 while($ligne = $rep -> fetch()) {
           echo '<option value="';
           echo $ligne['id_departement'];
           echo '" class="';
					 echo $ligne['id_region'];
					 echo '">';
           echo $ligne['nom_departement'];
           echo '</option>';
           echo "\n";
         }
         $rep -> closeCursor();
          ?>
       </select>
   </p>

    <p>
       <label for="intitule_gd">Domaine</label><br />
       <select name="intitule_gd" id="intitule_gd">
         <option value="0"> Indifférent </option>
         <?php
         $bdd = new PDO('mysql:host=localhost;dbname=projet;charset=utf8','root','root');
     		 $rep = $bdd->query('select id_grandediscipline, nom_grandediscipline from grandediscipline order by id_grandediscipline asc');
     		 while($ligne = $rep -> fetch()) {
           echo '<option value="';
           echo $ligne['id_grandediscipline'];
           echo '">';
           echo $ligne['nom_grandediscipline'];
           echo '</option>';
           echo "\n";
         }
         $rep -> closeCursor();
          ?>
       </select>
   </p>

   <p>
       <label for="discipline">Filière</label>
	   <br/>
       <select name="discipline" id="discipline">
         <?php
         $bdd = new PDO('mysql:host=localhost;dbname=projet;charset=utf8','root','root');
				 $rep = $bdd->query('select id_grandediscipline from filiere group by id_grandediscipline');
				 while($ligne = $rep -> fetch()) {
					 echo "<option value=0 class=".$ligne['id_grandediscipline']."> Indifférent </option>";
					 echo "\n";
				 }
				 $rep -> closeCursor();
     		 $rep = $bdd->query('select id_filiere, nom_filiere, id_grandediscipline from filiere order by id_filiere asc');
     		 while($ligne = $rep -> fetch()) {
					 echo '<option value="';
           echo $ligne['id_filiere'];
           echo '" class="';
					 echo $ligne['id_grandediscipline'];
					 echo '">';
           echo $ligne['nom_filiere'];
           echo '</option>';
           echo "\n";
         }
         $rep -> closeCursor();
          ?>
       </select>
   </p>

	<input type="submit" value="Consulter" >
</form>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="footer" class="clear">
    <!-- ####################################################################################################### -->
    <div class="fl_left clear">
      <div class="fl_left center">
	  <iframe width="250" height="250" frameborder="no" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.fr/maps?f=q&hl=fr&geocode=&q= 34 Route de Mende,34090 Montpellier&ie=UTF8&output=embed&s=AARTsJotOehFyV7Ld4EHPP1WtrZKl2G9Tw"></iframe>
	  </div>
      <address>
      34 Route de Mende<br />
      34090 Montpellier<br />
      France<br />
      <br />
      <strong>04 67 11 11 11</strong><br />
      Email: SearchYourUniversity@gmail.com
      </address>
    </div>

    <div id="copyright" class="clear">
      <p class="fl_left">Copyright &copy; 2017 - All Rights Reserved</p>
    </div>
    <!-- ####################################################################################################### -->
  </div>
</div>
</body>
</html>
