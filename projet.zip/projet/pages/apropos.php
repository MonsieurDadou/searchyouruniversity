<?php
	session_start();
?>
<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="../layout/styles/layout.css" type="text/css" />
<link rel="stylesheet" href="../layout/styles/catalogue.css" type="text/css" />
<title>Pourquoi s'inscrire </title>
</head>
<body>
<div class="wrapper row1">
  <div id="topnav">
    <ul>
      <li><a href="../index.php"><strong>Accueil</strong></a></li>
      <li><a href="catalogue.php"><strong>Catalogue des universités</strong></a></li>
      <li><a href="evaluation.php"><strong>Faire une évaluation</strong></a></li>
	   <?php
	  if(isset($_SESSION['utilisateur'])){
		echo '<li><a href="utilisateur/vosuniversites.php"><strong>Recherche guidée</strong></a></li>';
	  }
	   if(!isset($_SESSION['utilisateur'])){
		echo "<li><a href='utilisateur/inscription.php'><strong>S'inscrire</strong></a></li>";
	   }
	  ?>
	  <li class="active"><a href="apropos.php"><strong>A propos du site</strong></a></li>
    </ul>
  </div>
</div>



<div class="corps">
<h2> Pourquoi s'inscrire</h2>
<p>Si vous voulez une aide personnalisée afin de vous aider à trouver l'université qui vous convient le mieux en fonction de votre profil.

<p> En vous inscrivant SearchYourUniversity garde en sécurité vos recherches .
<br>
De plus, si vous voulez avoir des résultats plus précis et plus approfondis , cette étape reste obligatoire.
<br>
Eh oui nous avons besoin de connaître votre profil pour  vous aider au mieux .
<br>
Aussi, grâce à SearchYourUniversity vous pourrez être directement redirigé sur le site web de l'université afin de gagner du temps dans vos recherches.
<br>
Tout est clé en main !
</p>

</br>
</br>
<h2> Contact</h2>


<p> Ci-dessous les informations nécessaires pour tout renseignements complémentaires.</p>
<h3> Fondateurs</h3>
<p>Likong Chi Mireille</p>
<p>Marignan Marika</p>
<p>Samreth Darren</p>


<h3> Pour nous joindre</h3>

<p>SearchYourUniversity@gmail.com</p>
<p><strong>04 67 11 11 11</strong></p>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="footer" class="clear"> 
    <!-- ####################################################################################################### -->
    <div class="fl_left clear">
      <div class="fl_left center">
	  <iframe width="250" height="250" frameborder="no" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.fr/maps?f=q&hl=fr&geocode=&q= 34 Route de Mende,34090 Montpellier&ie=UTF8&output=embed&s=AARTsJotOehFyV7Ld4EHPP1WtrZKl2G9Tw"></iframe>
	  </div>
      <address>
      34 Route de Mende<br />
      34090 Montpellier<br />
      France<br />
      <br />
      <strong>04 67 11 11 11</strong><br />
      Email: SearchYourUniversity@gmail.com
      </address>
    </div>
    
    <div id="copyright" class="clear">
      <p class="fl_left">Copyright &copy; 2017 - All Rights Reserved</p>
    </div>
    <!-- ####################################################################################################### --> 
  </div>
</div>
</body>
</html>