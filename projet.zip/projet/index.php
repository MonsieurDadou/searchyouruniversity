﻿<!DOCTYPE html>
<?php
	session_start()
 ?>
<html>
<head>
<title>SearchYourUniversity</title>
<meta http-equiv="Content-Type" content="text/html;  charset=UTF-8"/>
<link rel="stylesheet" href="layout/styles/layout.css" type="text/css" />
<script type="text/javascript" src="layout/scripts/jquery.min.js"></script>
<!-- Featured Slider  -->
<script type="text/javascript" src="layout/scripts/jquery-s3slider.js"></script>
<script type="text/javascript">
$(document).ready(function() {
	$("#featured_slide_").s3Slider({
		timeOut:10000
	});
});
</script>
<!-- / Featured Slider -->
</head>
<body id="top">
<div class="wrapper row1">
  <div id="topnav">
    <ul>
      <li class="active"><a href="index.html"><strong>Accueil</strong></a></li>
      <li><a href="pages/catalogue.php"><strong>Catalogue des universités</strong></a></li>
      <li><a href="pages/evaluation.php"><strong>Faire une évaluation</strong></a></li>
	  <?php
	  if(isset($_SESSION['utilisateur'])){
		echo '<li><a href="pages/utilisateur/vosuniversites.php"><strong>Recherche guidée</strong></a></li>';
	  }
	   if(!isset($_SESSION['utilisateur'])){
		echo "<li><a href='pages/utilisateur/inscription.php'><strong>S'inscrire</strong></a></li>";
	   }
	  ?>
	  <li><a href="pages/apropos.php"><strong>A propos du site</strong></a></li>
    </ul>
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper row2">
  <div id="header" class="clear">
    <div class="fl_left">
      <h1>SearchYourUniversity</h1>
    </div>
		<?php
		if(isset($_SESSION['utilisateur'])){
			echo '<div class="fl_right">';
			echo "<br/>";
			echo "<br/>";
			echo '<p> Vous êtes connecté </p>';
			echo '<form action="pages/utilisateur/parametre.php" method="post" autocomplete="off">';
			echo '<input type="submit" value="Vos informations">';
			echo '</form>';
			echo "<br>";
			echo "\n";
			echo '<form action="pages/utilisateur/deconnecter.php" method="post" autocomplete="off">';
			echo '<input type="submit" value="Se deconnecter">';
			echo '</form>';
		}
		else{
			echo '<div class="fl_right">';
			echo "\n";
		  echo '<form action="pages/utilisateur/connecter.php" method="post" autocomplete="off">';
			echo "\n";
			echo '<p>';
			echo "\n";
			echo '<label for="pseudo">Adresse mail :</label>';
			echo "\n";
			echo '<input type="text" name="mail" id="mail" />';
			echo "\n";
			echo '<br />';
			echo '<label for="pass">Mot de passe :</label>';
			echo "\n";
			echo '<input type="password" name="motdepasse" id="motdepasse" />';
			echo "\n";
			echo '</p>';
			echo "\n";
			echo '<input type="checkbox" name="souvenir" id="souvenir" /> <label for="souvenir">Se souvenir de moi</label><br />';
			echo "\n";
			echo '<input type="submit" value="Se connecter">';
			echo "\n";
		  echo '</form>';
			echo "\n";
			echo '<form method="post" action="memoire.php">';
			echo "\n";
			echo '<p>';
			echo "\n";
			echo '</p>';
			echo "\n";
		  echo '</form>';
			echo "\n";
		  echo '<form action="pages/utilisateur/mdpoublie.html">';
			echo "\n";
			echo '<input type="submit" value="Mot de passe oublié" >';
			echo "\n";
			echo '</form>';
			echo "\n";
			echo '</div>';
			echo "\n";
		}
		?>
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper row3">
  <div id="featured_slide_">
    <ul id="featured_slide_Content">
      <li class="featured_slide_Image"><img src="images/campus.jpg" alt="" />
        <div class="introtext">
          <h2>Vous êtes étudiants ou  futur étudiants</h2>
		  <p> Vous n'avez aucune idée de la formation que vous aimeriez entreprendre ou vous avez quelques doutes. Vous êtes sur le bon site !!! Grâce à SearchYourUniversity  vous trouverez votre  formation aisément. Nous vous aiderons à trouver votre voie en fonction  de vos goûts et de vos critères.</p>
        </div>
      </li>
      <li class="featured_slide_Image"><img src="images/etudiants.jpg" alt="" />
        <div class="introtext">
          <h2>Vous êtes étudiants ou  futur étudiants</h2>
		  <p> Vous n'avez aucune idée de la formation que vous aimeriez entreprendre ou vous avez quelques doutes. Vous êtes sur le bon site !!! Grâce à SearchYourUniversity  vous trouverez votre  formation aisément. Nous vous aiderons à trouver votre voie en fonction  de vos goûts et de vos critères.</p>
        </div>
      </li>
      <li class="featured_slide_Image"><img src="images/titre.jpg" alt="" />
        <div class="introtext">
          <h2>Vous êtes étudiants ou  futur étudiants</h2>
		  <p> Vous n'avez aucune idée de la formation que vous aimeriez entreprendre ou vous avez quelques doutes. Vous êtes sur le bon site !!! Grâce à SearchYourUniversity  vous trouverez votre  formation aisément. Nous vous aiderons à trouver votre voie en fonction  de vos goûts et de vos critères.</p>
        </div>
      </li>
      <li class="clear featured_slide_Image"><!-- Important - Leave This Empty --></li>
    </ul>
  </div>
  <div id="hpage_featured_info" class="clear">
    <ul>
      <li><a href="pages/catalogue.php"><img src="images/catalogue.jpg" alt="Catalogue" /> <strong>Catalogue des universités</strong></a></li>
      <li><a href="pages/evaluation.php"><img src="images/notation.png" alt="Notation" /> <strong>Faire une évaluation</strong></a></li>
	   <?php
	  if(isset($_SESSION['utilisateur'])){
		echo '<li class="last"><a href="pages/utilisateur/vosuniversites.php"><img src="images/rechercher.png" alt="Recherche" /> <strong>Recherche guidée</strong></a></li>';
	  }
	  else{
		echo '<li class="last"><a href="pages/apropos.php"><img src="images/rechercher.png" alt="Recherche" /><strong>Recherche guidée</strong></a></li>';
	  }
	  ?>
    </ul>
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="footer" class="clear"> 
    <!-- ####################################################################################################### -->
    <div class="fl_left clear">
      <div class="fl_left center">
	  <iframe width="250" height="250" frameborder="no" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.fr/maps?f=q&hl=fr&geocode=&q= 34 Route de Mende,34090 Montpellier&ie=UTF8&output=embed&s=AARTsJotOehFyV7Ld4EHPP1WtrZKl2G9Tw"></iframe>
	  </div>
      <address>
      34 Route de Mende<br />
      34090 Montpellier<br />
      France<br />
      <br />
      <strong>04 67 11 11 11</strong><br />
      Email: SearchYourUniversity@gmail.com
      </address>
    </div>
    
    <div id="copyright" class="clear">
      <p class="fl_left">Copyright &copy; 2017 - All Rights Reserved</p>
    </div>
    <!-- ####################################################################################################### --> 
  </div>
</div>
</body>
</html>
